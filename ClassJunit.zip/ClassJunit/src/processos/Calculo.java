package processos;

public class Calculo {
	public static float ExecutaCalculo(float Valor1, float Valor2) {
		float Soma = Valor1 + Valor2;
		return Soma;
	}

}
